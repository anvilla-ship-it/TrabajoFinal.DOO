package biblioteca.controlador;

import biblioteca.dao.EstudianteDAO;
import biblioteca.modelo.Estudiante;

import java.util.List;

public class EstudianteControlador {

    private final EstudianteDAO dao = new EstudianteDAO();

    public boolean guardar(Estudiante estudiante) {
        return dao.guardar(estudiante);
    }

    public List<Estudiante> listar() {
        return dao.listar();
    }
}