package biblioteca.controlador;

import biblioteca.dao.PrestamoDAO;
import biblioteca.modelo.Prestamo;

import java.util.List;

public class PrestamoControlador {

    private final PrestamoDAO dao = new PrestamoDAO();

    public boolean guardar(Prestamo prestamo) {
        return dao.guardar(prestamo);
    }

    public List<Prestamo> listar() {
        return dao.listar();
    }
}