package biblioteca.controlador;

import biblioteca.dao.UsuarioDAO;
import biblioteca.modelo.Usuario;

import java.util.List;

public class UsuarioControlador {

    private final UsuarioDAO dao = new UsuarioDAO();

    public boolean guardar(Usuario usuario) {
        return dao.guardar(usuario);
    }

    public List<Usuario> listar() {
        return dao.listar();
    }
}