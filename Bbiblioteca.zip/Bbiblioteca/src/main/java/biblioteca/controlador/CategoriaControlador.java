package biblioteca.controlador;

import biblioteca.dao.CategoriaDAO;
import biblioteca.modelo.Categoria;

import java.util.List;

public class CategoriaControlador {

    private final CategoriaDAO dao = new CategoriaDAO();

    public boolean guardar(Categoria categoria) {
        return dao.guardar(categoria);
    }

    public List<Categoria> listar() {
        return dao.listar();
    }
}