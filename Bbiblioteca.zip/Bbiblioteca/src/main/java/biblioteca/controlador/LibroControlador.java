package biblioteca.controlador;

import biblioteca.dao.LibroDAO;
import biblioteca.modelo.Libro;

import java.util.List;

public class LibroControlador {

    private final LibroDAO dao = new LibroDAO();

    public boolean guardar(Libro libro) {
        return dao.guardar(libro);
    }

    public List<Libro> listar() {
        return dao.listar();
    }
}