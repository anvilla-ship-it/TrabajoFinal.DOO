package biblioteca.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class ConexionDB {

    private static final ConexionDB INSTANCIA = new ConexionDB();

    private static final String URL =
            "jdbc:mysql://localhost:3306/biblioteca";

    private static final String USUARIO = "root";

    // Escribe aquí la contraseña que ya te funcionaba.
    private static final String CLAVE = "Mi.Clave";

    private ConexionDB() {
    }

    public static ConexionDB getInstancia() {
        return INSTANCIA;
    }

    public Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }
}