package biblioteca.conexion;

import java.sql.Connection;
import java.sql.SQLException;

public class ProbarConexion {

    public static void main(String[] args) {
        try (Connection conexion =
                     ConexionDB.getInstancia().conectar()) {

            if (conexion.isValid(3)) {
                System.out.println("Conexión correcta con MySQL.");
                System.out.println(
                        "Singleton funcionando: "
                                + (ConexionDB.getInstancia()
                                == ConexionDB.getInstancia())
                );
            } else {
                System.out.println(
                        "La conexión no respondió a la validación."
                );
            }

        } catch (SQLException e) {
            System.err.println(
                    "No se pudo conectar con MySQL: "
                            + e.getMessage()
            );
        }
    }
}