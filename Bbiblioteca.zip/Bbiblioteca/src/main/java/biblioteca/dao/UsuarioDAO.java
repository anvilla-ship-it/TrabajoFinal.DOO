package biblioteca.dao;

import biblioteca.conexion.ConexionDB;
import biblioteca.modelo.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    public boolean guardar(Usuario usuario) {
        String sql = "INSERT INTO usuarios "
                + "(nombre, rut, correo, `contraseña`, rol) "
                + "VALUES (?, ?, ?, ?, ?)";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, usuario.getNombre());
                ps.setString(2, usuario.getRut());
                ps.setString(3, usuario.getCorreo());
                ps.setString(4, usuario.getContrasena());
                ps.setString(5, usuario.getRol());

                return ps.executeUpdate() > 0;

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al guardar usuario: " + e.getMessage()
                );
                return false;
            }
        }
    }

    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();

        String sql = "SELECT id, nombre, rut, correo, "
                + "`contraseña`, rol FROM usuarios ORDER BY id";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Usuario usuario = new Usuario(
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("rut"),
                            rs.getString("correo"),
                            rs.getString("contraseña"),
                            rs.getString("rol")
                    );

                    lista.add(usuario);
                }

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al listar usuarios: " + e.getMessage()
                );
            }
        }

        return lista;
    }
}