package biblioteca.dao;

import biblioteca.conexion.ConexionDB;
import biblioteca.modelo.Estudiante;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstudianteDAO {

    public boolean guardar(Estudiante estudiante) {
        String sql = "INSERT INTO estudiantes "
                + "(nombre, rut, curso, correo) VALUES (?, ?, ?, ?)";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, estudiante.getNombre());
                ps.setString(2, estudiante.getRut());
                ps.setString(3, estudiante.getCurso());
                ps.setString(4, estudiante.getCorreo());

                return ps.executeUpdate() > 0;

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al guardar estudiante: " + e.getMessage()
                );
                return false;
            }
        }
    }

    public List<Estudiante> listar() {
        List<Estudiante> lista = new ArrayList<>();

        String sql = "SELECT id, nombre, rut, curso, correo "
                + "FROM estudiantes ORDER BY id";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    lista.add(new Estudiante(
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("rut"),
                            rs.getString("curso"),
                            rs.getString("correo")
                    ));
                }

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al listar estudiantes: " + e.getMessage()
                );
            }
        }

        return lista;
    }
}