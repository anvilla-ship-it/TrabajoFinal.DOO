package biblioteca.dao;

import biblioteca.conexion.ConexionDB;
import biblioteca.modelo.Prestamo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDAO {

    public boolean guardar(Prestamo prestamo) {
        String sql = "INSERT INTO prestamos "
                + "(id_estudiante, id_libro, fecha_prestamo, "
                + "fecha_devolucion, devuelto) "
                + "VALUES (?, ?, ?, ?, ?)";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, prestamo.getIdEstudiante());
                ps.setInt(2, prestamo.getIdLibro());
                ps.setDate(3, prestamo.getFechaPrestamo());

                if (prestamo.getFechaDevolucion() == null) {
                    ps.setNull(4, Types.DATE);
                } else {
                    ps.setDate(4, prestamo.getFechaDevolucion());
                }

                ps.setBoolean(5, prestamo.isDevuelto());

                return ps.executeUpdate() > 0;

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al guardar préstamo: " + e.getMessage()
                );
                return false;
            }
        }
    }

    public List<Prestamo> listar() {
        List<Prestamo> lista = new ArrayList<>();

        String sql = "SELECT id, id_estudiante, id_libro, "
                + "fecha_prestamo, fecha_devolucion, devuelto "
                + "FROM prestamos ORDER BY id";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    lista.add(new Prestamo(
                            rs.getInt("id"),
                            rs.getInt("id_estudiante"),
                            rs.getInt("id_libro"),
                            rs.getDate("fecha_prestamo"),
                            rs.getDate("fecha_devolucion"),
                            rs.getBoolean("devuelto")
                    ));
                }

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al listar préstamos: " + e.getMessage()
                );
            }
        }

        return lista;
    }
}