package biblioteca.dao;

import biblioteca.conexion.ConexionDB;
import biblioteca.modelo.Libro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibroDAO {

    public boolean guardar(Libro libro) {
        String sql = "INSERT INTO libros "
                + "(titulo, autor, isbn, editorial, stock, id_categoria) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, libro.getTitulo());
                ps.setString(2, libro.getAutor());
                ps.setString(3, libro.getIsbn());
                ps.setString(4, libro.getEditorial());
                ps.setInt(5, libro.getStock());
                ps.setInt(6, libro.getIdCategoria());

                return ps.executeUpdate() > 0;

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al guardar libro: " + e.getMessage()
                );
                return false;
            }
        }
    }

    public List<Libro> listar() {
        List<Libro> lista = new ArrayList<>();

        String sql = "SELECT id, titulo, autor, isbn, editorial, "
                + "stock, id_categoria FROM libros ORDER BY id";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    lista.add(new Libro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            rs.getString("autor"),
                            rs.getString("isbn"),
                            rs.getString("editorial"),
                            rs.getInt("stock"),
                            rs.getInt("id_categoria")
                    ));
                }

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al listar libros: " + e.getMessage()
                );
            }
        }

        return lista;
    }
}