package biblioteca.dao;

public final class BloqueoBD {

    public static final Object LOCK = new Object();

    private BloqueoBD() {
    }
}