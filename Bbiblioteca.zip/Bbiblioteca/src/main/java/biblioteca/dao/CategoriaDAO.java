package biblioteca.dao;

import biblioteca.conexion.ConexionDB;
import biblioteca.modelo.Categoria;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    public boolean guardar(Categoria categoria) {
        String sql = "INSERT INTO categorias (nombre) VALUES (?)";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, categoria.getNombre());

                return ps.executeUpdate() > 0;

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al guardar categoría: " + e.getMessage()
                );
                return false;
            }
        }
    }

    public List<Categoria> listar() {
        List<Categoria> lista = new ArrayList<>();

        String sql = "SELECT id, nombre FROM categorias ORDER BY id";

        synchronized (BloqueoBD.LOCK) {
            try (Connection con =
                         ConexionDB.getInstancia().conectar();
                 PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    lista.add(new Categoria(
                            rs.getInt("id"),
                            rs.getString("nombre")
                    ));
                }

            } catch (SQLException | NullPointerException e) {
                System.err.println(
                        "Error al listar categorías: " + e.getMessage()
                );
            }
        }

        return lista;
    }
}