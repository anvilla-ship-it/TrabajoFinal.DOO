package biblioteca.vista;

import biblioteca.controlador.CategoriaControlador;
import biblioteca.controlador.EstudianteControlador;
import biblioteca.controlador.LibroControlador;
import biblioteca.controlador.PrestamoControlador;
import biblioteca.controlador.UsuarioControlador;

import biblioteca.modelo.Categoria;
import biblioteca.modelo.Estudiante;
import biblioteca.modelo.Libro;
import biblioteca.modelo.Prestamo;
import biblioteca.modelo.Usuario;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;

import java.sql.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

public class MenuPrincipal extends JFrame {

    private final UsuarioControlador usuarios =
            new UsuarioControlador();

    private final EstudianteControlador estudiantes =
            new EstudianteControlador();

    private final CategoriaControlador categorias =
            new CategoriaControlador();

    private final LibroControlador libros =
            new LibroControlador();

    private final PrestamoControlador prestamos =
            new PrestamoControlador();

    private final JTextArea salida = new JTextArea();

    public MenuPrincipal() {
        setTitle("BibliotecaEscolar");
        setSize(950, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel titulo = new JLabel(
                "Sistema BibliotecaEscolar",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        add(titulo, BorderLayout.NORTH);

        JPanel botones = new JPanel(new GridLayout(0, 2, 8, 8));

        agregarBoton(botones, "Agregar usuario", this::agregarUsuario);
        agregarBoton(botones, "Listar usuarios", this::listarUsuarios);

        agregarBoton(botones, "Agregar estudiante", this::agregarEstudiante);
        agregarBoton(botones, "Listar estudiantes", this::listarEstudiantes);

        agregarBoton(botones, "Agregar categoría", this::agregarCategoria);
        agregarBoton(botones, "Listar categorías", this::listarCategorias);

        agregarBoton(botones, "Agregar libro", this::agregarLibro);
        agregarBoton(botones, "Listar libros", this::listarLibros);

        agregarBoton(botones, "Agregar préstamo", this::agregarPrestamo);
        agregarBoton(botones, "Listar préstamos", this::listarPrestamos);

        agregarBoton(botones, "Limpiar pantalla",
                () -> salida.setText(""));

        add(botones, BorderLayout.CENTER);

        salida.setEditable(false);
        salida.setRows(10);
        salida.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));

        add(new JScrollPane(salida), BorderLayout.SOUTH);
    }

    private void agregarBoton(
            JPanel panel, String texto, Runnable accion) {

        JButton boton = new JButton(texto);
        boton.addActionListener(e -> accion.run());
        panel.add(boton);
    }

    private <T> void ejecutarEnSegundoPlano(
            Callable<T> tarea, Consumer<T> alTerminar) {

        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        new SwingWorker<T, Void>() {

            @Override
            protected T doInBackground() throws Exception {
                return tarea.call();
            }

            @Override
            protected void done() {
                setCursor(Cursor.getDefaultCursor());

                try {
                    alTerminar.accept(get());

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    mostrarError("La operación fue interrumpida.");

                } catch (ExecutionException e) {
                    Throwable causa =
                            e.getCause() == null ? e : e.getCause();

                    mostrarError(
                            "No se pudo completar la operación: "
                                    + causa.getMessage()
                    );
                }
            }
        }.execute();
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void mostrarResultado(boolean correcto, String entidad) {
        if (correcto) {
            JOptionPane.showMessageDialog(
                    this, entidad + " guardado/a correctamente."
            );
        } else {
            mostrarError(
                    "No se pudo guardar " + entidad
                            + ". Revisa los datos, las claves únicas y los ID relacionados."
            );
        }
    }

    private String pedir(String mensaje) {
        return JOptionPane.showInputDialog(this, mensaje);
    }

    private boolean faltanDatos(String... valores) {
        for (String valor : valores) {
            if (valor == null || valor.trim().isEmpty()) {
                return true;
            }
        }
        return false;
    }


    private void agregarUsuario() {
        String nombre = pedir("Nombre del usuario:");
        if (nombre == null) return;

        String rut = pedir("RUT:");
        if (rut == null) return;

        String correo = pedir("Correo:");
        if (correo == null) return;

        String clave = pedir("Contraseña:");
        if (clave == null) return;

        String rol = pedir("Rol: bibliotecario o estudiante:");
        if (rol == null) return;

        rol = rol.trim().toLowerCase();

        if (faltanDatos(nombre, rut, correo, clave, rol)) {
            mostrarError("Completa todos los campos.");
            return;
        }

        if (!rol.equals("bibliotecario")
                && !rol.equals("estudiante")) {
            mostrarError(
                    "El rol debe ser bibliotecario o estudiante."
            );
            return;
        }

        Usuario usuario = new Usuario(
                0,
                nombre.trim(),
                rut.trim(),
                correo.trim(),
                clave,
                rol
        );

        ejecutarEnSegundoPlano(
                () -> usuarios.guardar(usuario),
                ok -> mostrarResultado(ok, "el usuario")
        );
    }

    private void listarUsuarios() {
        ejecutarEnSegundoPlano(usuarios::listar, lista -> {
            StringBuilder sb = new StringBuilder("USUARIOS\n\n");

            for (Usuario u : lista) {
                sb.append("ID: ").append(u.getId())
                        .append(" | Nombre: ").append(u.getNombre())
                        .append(" | RUT: ").append(u.getRut())
                        .append(" | Correo: ").append(u.getCorreo())
                        .append(" | Rol: ").append(u.getRol())
                        .append('\n');
            }

            salida.setText(sb.toString());
        });
    }


    private void agregarEstudiante() {
        String nombre = pedir("Nombre del estudiante:");
        if (nombre == null) return;

        String rut = pedir("RUT:");
        if (rut == null) return;

        String curso = pedir("Curso:");
        if (curso == null) return;

        String correo = pedir("Correo:");
        if (correo == null) return;

        if (faltanDatos(nombre, rut, curso, correo)) {
            mostrarError("Completa todos los campos.");
            return;
        }

        Estudiante estudiante = new Estudiante(
                0,
                nombre.trim(),
                rut.trim(),
                curso.trim(),
                correo.trim()
        );

        ejecutarEnSegundoPlano(
                () -> estudiantes.guardar(estudiante),
                ok -> mostrarResultado(ok, "el estudiante")
        );
    }

    private void listarEstudiantes() {
        ejecutarEnSegundoPlano(estudiantes::listar, lista -> {
            StringBuilder sb =
                    new StringBuilder("ESTUDIANTES\n\n");

            for (Estudiante e : lista) {
                sb.append("ID: ").append(e.getId())
                        .append(" | Nombre: ").append(e.getNombre())
                        .append(" | RUT: ").append(e.getRut())
                        .append(" | Curso: ").append(e.getCurso())
                        .append(" | Correo: ").append(e.getCorreo())
                        .append('\n');
            }

            salida.setText(sb.toString());
        });
    }


    private void agregarCategoria() {
        String nombre = pedir("Nombre de la categoría:");
        if (nombre == null) return;

        if (nombre.trim().isEmpty()) {
            mostrarError("Escribe el nombre de la categoría.");
            return;
        }

        Categoria categoria =
                new Categoria(0, nombre.trim());

        ejecutarEnSegundoPlano(
                () -> categorias.guardar(categoria),
                ok -> mostrarResultado(ok, "la categoría")
        );
    }

    private void listarCategorias() {
        ejecutarEnSegundoPlano(categorias::listar, lista -> {
            StringBuilder sb =
                    new StringBuilder("CATEGORÍAS\n\n");

            for (Categoria c : lista) {
                sb.append("ID: ").append(c.getId())
                        .append(" | Nombre: ").append(c.getNombre())
                        .append('\n');
            }

            salida.setText(sb.toString());
        });
    }


    private void agregarLibro() {
        String titulo = pedir("Título del libro:");
        if (titulo == null) return;

        String autor = pedir("Autor:");
        if (autor == null) return;

        String isbn = pedir("ISBN:");
        if (isbn == null) return;

        String editorial = pedir("Editorial:");
        if (editorial == null) return;

        String stockTexto = pedir("Cantidad disponible (stock):");
        if (stockTexto == null) return;

        String categoriaTexto = pedir(
                "ID de una categoría existente. "
                        + "Pulsa Listar categorías para consultarlo:"
        );
        if (categoriaTexto == null) return;

        if (faltanDatos(
                titulo, autor, isbn, editorial,
                stockTexto, categoriaTexto)) {

            mostrarError("Completa todos los campos.");
            return;
        }

        try {
            int stock = Integer.parseInt(stockTexto.trim());
            int idCategoria =
                    Integer.parseInt(categoriaTexto.trim());

            if (stock < 0 || idCategoria <= 0) {
                mostrarError(
                        "El stock no puede ser negativo y "
                                + "el ID de categoría debe ser positivo."
                );
                return;
            }

            Libro libro = new Libro(
                    0,
                    titulo.trim(),
                    autor.trim(),
                    isbn.trim(),
                    editorial.trim(),
                    stock,
                    idCategoria
            );

            ejecutarEnSegundoPlano(
                    () -> libros.guardar(libro),
                    ok -> mostrarResultado(ok, "el libro")
            );

        } catch (NumberFormatException e) {
            mostrarError(
                    "El stock y el ID de categoría deben ser números."
            );
        }
    }

    private void listarLibros() {
        ejecutarEnSegundoPlano(libros::listar, lista -> {
            StringBuilder sb = new StringBuilder("LIBROS\n\n");

            for (Libro l : lista) {
                sb.append("ID: ").append(l.getId())
                        .append(" | Título: ").append(l.getTitulo())
                        .append(" | Autor: ").append(l.getAutor())
                        .append(" | ISBN: ").append(l.getIsbn())
                        .append(" | Editorial: ").append(l.getEditorial())
                        .append(" | Stock: ").append(l.getStock())
                        .append(" | ID categoría: ")
                        .append(l.getIdCategoria())
                        .append('\n');
            }

            salida.setText(sb.toString());
        });
    }

    private void agregarPrestamo() {
        String estudianteTexto =
                pedir("ID de un estudiante existente:");
        if (estudianteTexto == null) return;

        String libroTexto =
                pedir("ID de un libro existente:");
        if (libroTexto == null) return;

        String fechaPrestamoTexto =
                pedir("Fecha del préstamo (AAAA-MM-DD):");
        if (fechaPrestamoTexto == null) return;

        String fechaDevolucionTexto = pedir(
                "Fecha de devolución (AAAA-MM-DD), "
                        + "o deja vacío si aún no se devuelve:"
        );
        if (fechaDevolucionTexto == null) return;

        String devueltoTexto =
                pedir("¿Ya fue devuelto? Escribe si o no:");
        if (devueltoTexto == null) return;

        if (faltanDatos(
                estudianteTexto, libroTexto,
                fechaPrestamoTexto, devueltoTexto)) {

            mostrarError(
                    "Completa los campos obligatorios. "
                            + "La fecha de devolución puede quedar vacía."
            );
            return;
        }

        try {
            int idEstudiante =
                    Integer.parseInt(estudianteTexto.trim());

            int idLibro =
                    Integer.parseInt(libroTexto.trim());

            if (idEstudiante <= 0 || idLibro <= 0) {
                mostrarError("Los ID deben ser números positivos.");
                return;
            }

            Date fechaPrestamo =
                    Date.valueOf(fechaPrestamoTexto.trim());

            Date fechaDevolucion =
                    fechaDevolucionTexto.trim().isEmpty()
                            ? null
                            : Date.valueOf(fechaDevolucionTexto.trim());

            String respuesta =
                    devueltoTexto.trim().toLowerCase();

            if (!respuesta.equals("si")
                    && !respuesta.equals("sí")
                    && !respuesta.equals("no")) {

                mostrarError("Escribe si o no para indicar la devolución.");
                return;
            }

            boolean devuelto =
                    respuesta.equals("si") || respuesta.equals("sí");

            if (devuelto && fechaDevolucion == null) {
                mostrarError(
                        "Si ya fue devuelto, ingresa la fecha de devolución."
                );
                return;
            }

            Prestamo prestamo = new Prestamo(
                    0,
                    idEstudiante,
                    idLibro,
                    fechaPrestamo,
                    fechaDevolucion,
                    devuelto
            );

            ejecutarEnSegundoPlano(
                    () -> prestamos.guardar(prestamo),
                    ok -> mostrarResultado(ok, "el préstamo")
            );

        } catch (IllegalArgumentException e) {
            mostrarError(
                    "Revisa los ID y las fechas. "
                            + "Usa el formato AAAA-MM-DD."
            );
        }
    }

    private void listarPrestamos() {
        ejecutarEnSegundoPlano(prestamos::listar, lista -> {
            StringBuilder sb = new StringBuilder("PRÉSTAMOS\n\n");

            for (Prestamo p : lista) {
                sb.append("ID: ").append(p.getId())
                        .append(" | ID estudiante: ")
                        .append(p.getIdEstudiante())
                        .append(" | ID libro: ")
                        .append(p.getIdLibro())
                        .append(" | Fecha préstamo: ")
                        .append(p.getFechaPrestamo())
                        .append(" | Fecha devolución: ")
                        .append(p.getFechaDevolucion())
                        .append(" | Devuelto: ")
                        .append(p.isDevuelto())
                        .append('\n');
            }

            salida.setText(sb.toString());
        });
    }
}